/*
 * Public API Surface of start-page-v2
 */

import { from } from 'rxjs';

export * from './lib/start-page-v2.service';
export * from './lib/start-page-v2.component';
export * from './lib/start-page-v2.module';
export * from './lib/start-page/start-page.component';
