import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sb-start-page-v2',
  template: `
    <p>
      start-page-v2 works!
    </p>
  `,
  styles: []
})
export class StartPageV2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
